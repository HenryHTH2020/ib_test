#!/bin/bash

./client.sh > "$(date +%Y-%m-%d\ %H:%M:%S)file.out" 2>&1 &